Reviewed Quintavalle Published/Ours repair, local snapshot 866185396eebf2b619fd04ce45a882040e59722d
Study: formalization/quintavalle-hgp
Main PDF: formalization/quintavalle-hgp/paper/hypergraph_product_codes__finite_support_and_unresolved_production_results.pdf
Rebuild and scientific rerun instructions: study README.md and paper Appendix B.
Reusable skill and regression tests: .agents/skills/replication-paper
Scientific outputs were not rerun or changed by this repair. Source ink, universal proofs and full production fits remain unresolved.
Study links to master are not currently available online; corresponding files are included in this archive. No publication is implied.
ARCHIVE-MANIFEST.json gives SHA256 for every snapshot file; it excludes these two archive metadata files. Historical rejected artifacts are retained under provenance, not the main paper path.
