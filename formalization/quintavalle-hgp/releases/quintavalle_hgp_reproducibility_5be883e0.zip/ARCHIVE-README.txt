Committed reproducibility snapshot at 5be883e07814247c4b5bdaa369e656ea8788ccee
Start with formalization/quintavalle-hgp/README.md.
Includes code, original vendored decoder, captured results, source text, reviewed PDF, editable manuscript, evidence and review records, and replication skill.
Git history, executables and virtual environments are excluded. Scientific runs rebuild from supplied source. Git-history validation helpers require the original checkout at the recorded commit; archive file hashes are independently listed in ARCHIVE-MANIFEST.json.
The dissertation replication is incomplete. Full production fits, universal proofs and source-PDF ink checks remain unestablished. The old delivery record describes the pre-attachment state; this archive does not imply a repository push or public publication.
